document.getElementById('github-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const response = await fetch(`/api/github/${username}`);
    const data = await response.json();
    document.getElementById('result').textContent = JSON.stringify(data, null, 2);
});

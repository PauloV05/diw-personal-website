const carouselSlides = document.querySelector('.carousel-slides');
const carouselItems = document.querySelectorAll('.carousel-item');
let currentSlide = 0;

const changeSlide = () => {
  carouselItems[currentSlide].classList.remove('active');
  currentSlide = (currentSlide + 1) % carouselItems.length;
  carouselItems[currentSlide].classList.add('active');
};

const startCarousel = () => {
  setInterval(changeSlide, 5000);
};

startCarousel();
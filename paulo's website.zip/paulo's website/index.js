const express = require('express');
const fetch = require('node-fetch');
const app = express();
const port = 3000;

app.use(express.static('public'));

app.get('/api/github/:username', async (req, res) => {
    const username = req.params.username;
    const url = `https://api.github.com/users/${username}`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching data from GitHub' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
